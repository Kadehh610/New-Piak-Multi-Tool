## PiakMultiTools-Deobfuscated

## Quick fact

It is just a modified version of Radu-Tool

## Why did I do that?
Simple, Github is a place where you're supposed to show the source code, if you are not don't use github.

I still need to deobfuscate some pyarmor then everything to see for everyone !!

Original repository : https://github.com/PiakCorp/PiakMultiTools

You can contribute to this repository if you wish for

Always run in a VM
IM NOT RESPONSIBLE FOR YOUR ACTIONS
